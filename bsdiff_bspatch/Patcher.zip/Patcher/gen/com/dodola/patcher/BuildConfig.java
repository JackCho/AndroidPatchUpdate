/** Automatically generated file. DO NOT MODIFY */
package com.dodola.patcher;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}