package com.dodola.patcher;


public class GloableParams {
	public static String PROXY_IP;
	public static Integer PROXY_PORT;
}
