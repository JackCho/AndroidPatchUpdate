#ifndef BSPATCH_H
#define BSPATCH_H

extern int bspatch(char **argv);

#endif /* BSPATCH_H */
